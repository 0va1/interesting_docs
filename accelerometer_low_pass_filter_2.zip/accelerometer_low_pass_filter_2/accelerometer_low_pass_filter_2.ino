#include <Arduino_BuiltIn.h>            //https://github.com/hanyazou/BMI160-Arduino

const int xInput = 2;     // accelerometer analog input pin

int xRaw=0;
const int buttonPin = 5;  // ref. digital input pin
int buttonState = 0;
float filteredValue = 0;
const float alpha = 0.04; // smoothing factor


void setup() {
  // Initialize Serial communication at 115200 baud rate
  Serial.begin(115200);
  pinMode (buttonPin, INPUT);
  analogReadResolution (10);
  }

void loop() {
  buttonState = 5*digitalRead (buttonPin);  //read the state of the ref signal
  xRaw = analogRead (xInput);               //read raw analog value

  //Low pass filter
  filteredValue = alpha * xRaw + (1-alpha) * filteredValue; 

  // Print values
  Serial.print("xRaw:");
  Serial.print(xRaw-85);
  Serial.print(", ");
  Serial.print("filtered:");
  Serial.print(2*filteredValue-171);
  Serial.print(", ref:");
  Serial.println(buttonState);
  
}
